<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>فروشگاه سیسمونی نوزاد | دنیای کوچولوها</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Vazirmatn:wght@100;200;300;400;500;600;700;800;900&display=swap');
        
        body {
            font-family: 'Vazirmatn', sans-serif;
            background-color: #fef6f6;
        }
        
        .hero-pattern {
            background-image: radial-gradient(#fbcfe8 1px, transparent 1px);
            background-size: 20px 20px;
        }
        
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }
        
        .cart-item-enter {
            opacity: 0;
            transform: translateX(20px);
        }
        
        .cart-item-enter-active {
            opacity: 1;
            transform: translateX(0);
            transition: all 300ms ease-in;
        }
        
        .cart-item-exit {
            opacity: 1;
        }
        
        .cart-item-exit-active {
            opacity: 0;
            transform: translateX(20px);
            transition: all 300ms ease-in;
        }
        
        .admin-nav-item.active {
            background-color: #fce7f3;
            border-right: 4px solid #ec4899;
        }
        
        .review-card:nth-child(odd) {
            background-color: #fdf2f8;
        }
        
        .review-card:nth-child(even) {
            background-color: #f0f9ff;
        }
        
        /* Animation for baby items */
        @keyframes float {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
            100% { transform: translateY(0px); }
        }
        
        .floating {
            animation: float 3s ease-in-out infinite;
        }
        
        .delay-1 {
            animation-delay: 0.5s;
        }
        
        .delay-2 {
            animation-delay: 1s;
        }
        
        .delay-3 {
            animation-delay: 1.5s;
        }
    </style>
</head>
<body class="text-gray-800">
    <!-- Header -->
    <header class="bg-white shadow-sm sticky top-0 z-50">
        <div class="container mx-auto px-4 py-3 flex justify-between items-center">
            <div class="flex items-center space-x-2 space-x-reverse">
                <div class="w-10 h-10 bg-pink-500 rounded-full flex items-center justify-center text-white">
                    <i class="fas fa-baby text-xl"></i>
                </div>
                <h1 class="text-xl font-bold text-pink-600">دنیای کوچولوها</h1>
            </div>
            
            <nav class="hidden md:flex space-x-8 space-x-reverse">
                <a href="index.php" class="text-pink-600 font-medium hover:text-pink-800 transition">خانه</a>
                <a href="products.php" class="text-gray-600 hover:text-pink-600 transition">محصولات</a>
                <a href="about.php" class="text-gray-600 hover:text-pink-600 transition">درباره ما</a>
                <a href="reviews.php" class="text-gray-600 hover:text-pink-600 transition">نظرات</a>
                <a href="contact.php" class="text-gray-600 hover:text-pink-600 transition">تماس با ما</a>
            </nav>
            <div class="flex items-center space-x-4 space-x-reverse">
            <!-- سبد خرید -->
            <a href="cart.php" title="سبد خرید " class="relative">
                 <i class="fas fa-shopping-cart text-xl text-gray-600 hover:text-pink-600"></i>
                 </a>

           <!-- پنل مدیریت -->
            <a href="login.php" title="پنل مدیریت" class="relative">
               <i class="fas fa-user-shield text-xl text-gray-600 hover:text-pink-600"></i>
           </a>
            </div>

        
        <!-- Mobile Menu -->
        <div id="mobile-menu" class="hidden md:hidden bg-white border-t py-2 px-4">
            <div class="flex flex-col space-y-3">
                <a href="index.php" class="text-pink-600 font-medium">خانه</a>
                <a href="products.php" class="text-gray-600">محصولات</a>
                <a href="about.php" class="text-gray-600">درباره ما</a>
                <a href="reviews.php" class="text-gray-600">نظرات</a>
                <a href="contact.php" class="text-gray-600">تماس با ما</a>
            </div>
        </div>
    </header>