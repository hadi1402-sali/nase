<?php
include("header.php");
include("connec.php");
mysqli_set_charset($connect, "utf8mb4");

// دریافت و اعتبارسنجی ID
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// اجرای حذف اگر ID معتبر بود
if ($id > 0) {
    $query = "DELETE FROM images WHERE id = ?";
    $stmt = mysqli_prepare($connect, $query);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $deleted = mysqli_stmt_affected_rows($stmt) > 0;
    mysqli_stmt_close($stmt);
} else {
    $deleted = false;
}
?>
<div class="min-h-screen bg-gradient-to-r from-pink-50 to-purple-50 flex items-center justify-center p-6">
    <div class="max-w-md w-full bg-white rounded-3xl shadow-xl border border-pink-200 p-8 text-center">
        <?php if ($deleted): ?>
            <h2 class="text-3xl font-extrabold text-pink-700 mb-6">تصویر با موفقیت حذف شد.</h2>
            <p class="text-pink-600 mb-8">عملیات حذف با موفقیت انجام شد و تصویر از سیستم پاک شده است.</p>
        <?php else: ?>
            <h2 class="text-3xl font-extrabold text-red-500 mb-6">خطا در حذف تصویر یا تصویر یافت نشد.</h2>
            <p class="text-red-400 mb-8">لطفا دوباره تلاش کنید یا از صحت آدرس اطمینان حاصل کنید.</p>
        <?php endif; ?>
        <a href="login_action.php"
           class="inline-block bg-gradient-to-r from-pink-500 to-pink-700 hover:from-pink-600 hover:to-pink-800 text-white font-bold py-3 px-10 rounded-2xl shadow-lg transition duration-300">
            بازگشت به پنل مدیریت
        </a>
    </div>
</div>

<?php include("footer.php"); ?>
