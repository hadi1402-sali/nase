<?php include("header.php"); ?> 

<!-- About Us Section -->
<section id="about" class="py-20 bg-gradient-to-r from-pink-50 to-purple-50">
    <div class="container mx-auto px-6">
        <div class="flex flex-col md:flex-row items-center md:space-x-12 space-y-12 md:space-y-0">

            <!-- متن درباره ما -->
            <div class="md:w-1/2 bg-white p-10 rounded-3xl shadow-xl">
                <h2 class="text-4xl font-extrabold text-pink-700 mb-8 tracking-wide">درباره دنیای کوچولوها</h2>
                <p class="text-gray-700 mb-6 leading-relaxed text-lg">
                    فروشگاه سیسمونی نوزاد <span class="font-semibold text-pink-600">«دنیای کوچولوها»</span> با بیش از یک دهه سابقه، مفتخر است بهترین و باکیفیت‌ترین محصولات نوزاد را به خانواده‌های ایرانی عرضه کند. ما معتقدیم که هر کوچولویی شایسته بهترین‌هاست.
                </p>
                <p class="text-gray-700 mb-8 leading-relaxed text-lg">
                    تمام محصولات ما از مواد اولیه کاملاً طبیعی و استانداردهای جهانی ساخته شده‌اند تا با پوست حساس نوزادان شما کاملاً سازگار باشند و آرامش و سلامت را به خانواده شما هدیه دهند.
                </p>

                <!-- آمار جذاب با آیکون -->
                <div class="grid grid-cols-3 gap-6 text-center">
                    <div class="bg-pink-100 rounded-xl py-6 shadow-md">
                        <svg xmlns="http://www.w3.org/2000/svg" class="mx-auto h-10 w-10 text-pink-600 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 13V7a4 4 0 00-8 0v6m-2 4h12" />
                        </svg>
                        <h3 class="text-2xl font-bold text-pink-600">۵۰۰۰+</h3>
                        <p class="text-gray-600 text-sm mt-1">محصول متنوع</p>
                    </div>
                    <div class="bg-purple-100 rounded-xl py-6 shadow-md">
                        <svg xmlns="http://www.w3.org/2000/svg" class="mx-auto h-10 w-10 text-purple-600 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h3m0 0h3m-3 0v3m0-3v-3m12 6a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <h3 class="text-2xl font-bold text-purple-600">۱۰۰۰۰+</h3>
                        <p class="text-gray-600 text-sm mt-1">مشتری راضی</p>
                    </div>
                    <div class="bg-yellow-100 rounded-xl py-6 shadow-md">
                        <svg xmlns="http://www.w3.org/2000/svg" class="mx-auto h-10 w-10 text-yellow-500 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6 1a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <h3 class="text-2xl font-bold text-yellow-500">۱۰ سال</h3>
                        <p class="text-gray-600 text-sm mt-1">تجربه درخشان</p>
                    </div>
                </div>
            </div>

            <!-- تصاویر زیبای سیسمونی -->
            <div class="md:w-1/2 grid grid-cols-2 gap-6">
                <div class="rounded-3xl overflow-hidden shadow-lg transform hover:scale-105 transition duration-300">
                    <img src="https://yeto.ir/wp-content/uploads/2024/01/sismoni4.jpg" alt="فروشگاه ما" class="w-full h-64 object-cover rounded-3xl">
                </div>
                <div class="rounded-3xl overflow-hidden shadow-lg transform hover:scale-105 transition duration-300">
                    <img src="https://app.akharinkhabar.ir/images/2016/08/30/0665d2ee-ef8a-4e65-a0c4-e76691cd0e15.jpeg" alt="تیم ما" class="w-full h-64 object-cover rounded-3xl">
                </div>
                <div class="rounded-3xl overflow-hidden shadow-lg transform hover:scale-105 transition duration-300">
                    <img src="https://baby-kala.com/wp-content/uploads/2020/11/%D9%86%D9%88%D8%B2%D8%A7%D8%AF-1024x1024.jpg" alt="محصولات نوزاد" class="w-full h-64 object-cover rounded-3xl">
                </div>
                <div class="rounded-3xl overflow-hidden shadow-lg transform hover:scale-105 transition duration-300">
                    <img src="https://snapp.market/blog/wp-content/uploads/2022/04/baby-diapers-types-2.jpg" alt="نوزاد خوشحال" class="w-full h-64 object-cover rounded-3xl">
                </div>
            </div>

        </div>
    </div>
</section>

<?php include("footer.php"); ?>
