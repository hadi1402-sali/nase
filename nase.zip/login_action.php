<?php
include("header.php");
include("connec.php");
mysqli_set_charset($connect, "utf8mb4");
?>

<!-- پنل مدیریت -->
<div class="min-h-screen bg-pink-50">
    <nav class="bg-white shadow-lg border-b border-pink-300">
        <div class="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
            <span class="text-2xl font-extrabold text-pink-700 tracking-wide">پنل مدیریت بهار</span>
            <button onclick="window.location.href='index.php'" 
                class="bg-red-600 hover:bg-red-700 transition-colors duration-300 text-white font-bold py-2 px-6 rounded-lg shadow-md">
                خروج از پنل
            </button>
        </div>
    </nav>

    <main class="max-w-7xl mx-auto px-6 py-12">
        <div class="bg-white p-8 rounded-3xl shadow-xl border border-pink-200">
            <div class="flex items-center justify-between mb-10">
                <h2 class="text-3xl font-bold text-pink-800">مدیریت محصولات</h2>
                <button onclick="window.location.href='save.php'" 
                    class="bg-pink-700 hover:bg-pink-800 transition-colors duration-300 text-white font-semibold py-3 px-7 rounded-xl shadow-lg">
                    + افزودن محصول جدید
                </button>
            </div>

            <div class="overflow-x-auto rounded-2xl shadow-inner border border-pink-100">
                <table class="min-w-full divide-y divide-pink-200 bg-pink-50 rounded-2xl overflow-hidden">
                    <thead class="bg-pink-200 text-right text-sm font-semibold text-pink-900 select-none">
                        <tr>
                            <th class="px-6 py-4">نام</th>
                            <th class="px-6 py-4">قیمت (تومان)</th>
                            <th class="px-6 py-4">توضیحات</th>
                            <th class="px-6 py-4">تصویر</th>
                            <th class="px-6 py-4 text-left">عملیات</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-pink-100 text-sm bg-white">
                        <?php
                        $result = mysqli_query($connect, "SELECT * FROM images");
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<tr class='hover:bg-pink-100 transition-colors duration-200'>";
                            echo "<td class='px-6 py-4 text-pink-900 font-semibold whitespace-nowrap'>" . htmlspecialchars($row['name']) . "</td>";
                            echo "<td class='px-6 py-4 text-pink-800 font-medium'>" . number_format($row['price']) . "</td>";
                            echo "<td class='px-6 py-4 text-pink-700 max-w-xs truncate' title='" . htmlspecialchars($row['description']) . "'>" . htmlspecialchars($row['description']) . "</td>";
                            echo "<td class='px-6 py-4'>";
                            if (!empty($row['image_url'])) {
                                echo "<img src='" . htmlspecialchars($row['image_url']) . "' alt='تصویر' class='w-16 h-16 object-cover rounded-lg border border-pink-300 shadow-sm'>";
                            } else {
                                echo "<span class='text-gray-400 italic'>تصویری موجود نیست</span>";
                            }
                            echo "</td>";
                            echo "<td class='px-6 py-4 text-left flex gap-5 items-center'>";
                            echo "<a href='edit_product.php?id=" . $row['id'] . "' class='text-pink-700 hover:text-pink-900 transition-colors duration-200' title='ویرایش'><i class='fas fa-edit fa-lg'></i></a>";
                            echo "<a href='delete_product.php?id=" . $row['id'] . "' onclick=\"return confirm('آیا مطمئن هستید که می‌خواهید این محصول را حذف کنید؟');\" class='text-red-600 hover:text-red-800 transition-colors duration-200' title='حذف'><i class='fas fa-trash fa-lg'></i></a>";
                            echo "</td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div>

<?php
mysqli_close($connect);
include("footer.php");
?>
