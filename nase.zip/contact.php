<?php include("header.php");?>
  <!-- Contact Us -->
  <section id="contact" class="py-16 bg-white">
        <div class="container mx-auto px-4">
            <div class="max-w-4xl mx-auto">
                <h2 class="text-3xl font-bold text-center mb-10">تماس با ما</h2>
                
                <div class="flex flex-col md:flex-row gap-8">
                    <div class="md:w-1/2">
                        <form id="contact-form" class="space-y-4">
                            <div>
                                <label for="name" class="block text-gray-700 mb-2">نام و نام خانوادگی</label>
                                <input type="text" id="name" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent">
                            </div>
                            
                            <div>
                                <label for="email" class="block text-gray-700 mb-2">ایمیل</label>
                                <input type="email" id="email" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent">
                            </div>
                            
                            <div>
                                <label for="phone" class="block text-gray-700 mb-2">شماره تماس</label>
                                <input type="tel" id="phone" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent">
                            </div>
                            
                            <div>
                                <label for="message" class="block text-gray-700 mb-2">پیام شما</label>
                                <textarea id="message" rows="4" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent"></textarea>
                            </div>
                            
                            <button type="submit" class="w-full bg-pink-500 hover:bg-pink-600 text-white px-6 py-3 rounded-lg font-medium transition">
                                ارسال پیام
                            </button>
                        </form>
                    </div>
                    
                    <div class="md:w-1/2">
                        <div class="bg-gray-50 p-6 rounded-xl h-full">
                            <h3 class="text-xl font-bold mb-6">اطلاعات تماس</h3>
                            
                            <div class="space-y-4">
                                <div class="flex items-start space-x-3 space-x-reverse">
                                    <div class="w-10 h-10 bg-pink-100 rounded-full flex items-center justify-center text-pink-600">
                                        <i class="fas fa-map-marker-alt"></i>
                                    </div>
                                    <div>
                                        <h4 class="font-medium">آدرس فروشگاه</h4>
                                        <p class="text-gray-600 text-sm">تهران، خیابان ولیعصر، کوچه فلان، پلاک 123</p>
                                    </div>
                                </div>
                                
                                <div class="flex items-start space-x-3 space-x-reverse">
                                    <div class="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center text-blue-600">
                                        <i class="fas fa-phone"></i>
                                    </div>
                                    <div>
                                        <h4 class="font-medium">تلفن تماس</h4>
                                        <p class="text-gray-600 text-sm">021-12345678</p>
                                        <p class="text-gray-600 text-sm">0912-345-6789</p>
                                    </div>
                                </div>
                                
                                <div class="flex items-start space-x-3 space-x-reverse">
                                    <div class="w-10 h-10 bg-yellow-100 rounded-full flex items-center justify-center text-yellow-600">
                                        <i class="fas fa-envelope"></i>
                                    </div>
                                    <div>
                                        <h4 class="font-medium">ایمیل</h4>
                                        <p class="text-gray-600 text-sm">info@donyayekocholooha.ir</p>
                                        <p class="text-gray-600 text-sm">support@donyayekocholooha.ir</p>
                                    </div>
                                </div>
                                
                                <div class="flex items-start space-x-3 space-x-reverse">
                                    <div class="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center text-green-600">
                                        <i class="fas fa-clock"></i>
                                    </div>
                                    <div>
                                        <h4 class="font-medium">ساعات کاری</h4>
                                        <p class="text-gray-600 text-sm">شنبه تا چهارشنبه: 9 صبح تا 6 عصر</p>
                                        <p class="text-gray-600 text-sm">پنجشنبه: 9 صبح تا 2 بعدازظهر</p>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mt-8">
                                <h4 class="font-medium mb-3">ما را در شبکه های اجتماعی دنبال کنید</h4>
                                <div class="flex space-x-3 space-x-reverse">
                                    <a href="#" class="w-10 h-10 bg-pink-100 rounded-full flex items-center justify-center text-pink-600 hover:bg-pink-200 transition">
                                        <i class="fab fa-instagram"></i>
                                    </a>
                                    <a href="#" class="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 hover:bg-blue-200 transition">
                                        <i class="fab fa-telegram"></i>
                                    </a>
                                    <a href="#" class="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white hover:bg-blue-600 transition">
                                        <i class="fab fa-twitter"></i>
                                    </a>
                                    <a href="#" class="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center text-red-600 hover:bg-red-200 transition">
                                        <i class="fab fa-youtube"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php include("footer.php");?>