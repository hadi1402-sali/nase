<?php
include("header.php");
include("connec.php");
mysqli_set_charset($connect, "utf8mb4");

// چک کردن ارسالی بودن فرم
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $id = intval($_POST['id']);
    $name = trim($_POST['name']);
    $price = floatval($_POST['price']);
    $description = trim($_POST['description']);
    $image_url = trim($_POST['image_url']);

    $query = "UPDATE images SET name = ?, price = ?, description = ?, image_url = ? WHERE id = ?";
    $stmt = mysqli_prepare($connect, $query);
    if (!$stmt) {
        die("<div class='text-red-600 font-bold my-4'>خطا در آماده‌سازی کوئری: " . mysqli_error($connect) . "</div>");
    }

    mysqli_stmt_bind_param($stmt, "sdssi", $name, $price, $description, $image_url, $id);

    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['success'] = "✅ محصول با موفقیت ویرایش شد.";
        header("Location: login_action.php"); // اگر صفحه مقصد تغییر کرد، اینجا اصلاح کن
        exit;
    } else {
        echo "<div class='text-red-600 font-bold my-4'>خطا در ویرایش محصول: " . mysqli_stmt_error($stmt) . "</div>";
    }
} else {
    header("Location: login_action.php"); // اگر صفحه مقصد تغییر کرد، اینجا اصلاح کن

}

include("footer.php");
?>
