<?php include("header.php"); ?>
<?php
session_start();
include("connec.php");
mysqli_set_charset($connect, "utf8mb4");

// افزودن به سبد خرید
if (isset($_GET['add_to_cart'])) {
    $id = intval($_GET['add_to_cart']);
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = array();
    }

    if (isset($_SESSION['cart'][$id])) {
        $_SESSION['cart'][$id]++;
    } else {
        $_SESSION['cart'][$id] = 1;
    }

    header("Location: products.php");
    exit;
}
?>
<div class="bg-gradient-to-r from-pink-50 to-purple-50 rounded-xl p-8 mb-12 min-h-screen">
    <nav class="bg-white shadow-md rounded-2xl border border-pink-200 max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
        <div class="flex items-center space-x-3 rtl:space-x-reverse">
            <span class="text-3xl font-extrabold text-pink-700 select-none">👶🏻</span>
            <span class="text-2xl font-extrabold text-pink-700 tracking-wide">سیسمونی دنیای کوچولوها</span>
        </div>
        <a href="cart.php" 
           class="relative bg-pink-400 hover:bg-pink-500 text-white font-semibold py-3 px-7 rounded-full shadow-lg
                  transition-transform duration-300 hover:scale-105 flex items-center gap-2 select-none">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" stroke="currentColor" stroke-width="2" 
                 viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                <circle cx="9" cy="21" r="1"></circle>
                <circle cx="20" cy="21" r="1"></circle>
                <path d="M1 1h4l2.68 13.39a2 2 0 002 1.61h9.72a2 2 0 001.94-1.45l1.54-7.7H6"></path>
            </svg>
            سبد خرید
            <span class="absolute -top-2 -right-3 bg-red-600 text-white rounded-full px-3 text-xs font-bold shadow-lg">
                <?= array_sum($_SESSION['cart'] ?? []) ?>
            </span>
        </a>
    </nav>

    <main class="max-w-7xl mx-auto px-6 py-12">
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
            <?php
            $select_query = "SELECT * FROM images";
            $result = mysqli_query($connect, $select_query);

            if (!$result) {
                echo "<div class='text-red-600 font-bold'>خطا در بارگذاری محصولات: " . mysqli_error($connect) . "</div>";
            } else {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo '<div class="bg-white rounded-3xl shadow-xl p-6 flex flex-col justify-between hover:shadow-2xl transition-shadow duration-300 border border-pink-200">';
                    echo '<img src="' . htmlspecialchars($row['image_url']) . '" alt="تصویر" class="h-48 w-full object-cover rounded-2xl mb-5 shadow-inner">';
                    echo '<h3 class="text-pink-700 font-extrabold text-lg mb-2">' . htmlspecialchars($row['name']) . '</h3>';
                    echo '<p class="text-pink-600 text-sm mb-4 line-clamp-3">' . htmlspecialchars($row['description']) . '</p>';
                    echo '<div class="text-pink-700 font-bold text-xl mb-6">' . number_format($row['price']) . ' تومان</div>';
                    echo '<a href="products.php?add_to_cart=' . $row['id'] . '" class="self-start bg-gradient-to-r from-pink-400 to-pink-600 hover:from-pink-500 hover:to-pink-700 text-white font-semibold py-3 px-6 rounded-2xl shadow-md transition duration-300 hover:scale-105 transform">';
                    echo 'افزودن به سبد خرید';
                    echo '</a>';
                    echo '</div>';
                }
            }
            ?>
        </div>
    </main>
</div>

<?php include("footer.php"); ?>
