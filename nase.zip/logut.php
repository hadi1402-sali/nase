<?php
include("header.php");
unset($_SESSION["username"]);
unset($_SESSION["password"]);

?>
<script>
    location.replace("index.php");
</script>

<?php
include("footer.html");
?>