<?php include("header.php"); ?>

<div class="flex items-center justify-center min-h-screen bg-gradient-to-br from-pink-50 to-pink-200 px-6">
    <div class="bg-white shadow-2xl rounded-3xl px-10 pt-10 pb-12 w-full max-w-md border border-pink-300
                transform transition-transform duration-300 hover:scale-[1.03]">
        <h2 class="text-center text-4xl font-extrabold text-pink-700 mb-8 tracking-wide drop-shadow-md font-serif">
            ورود به پنل مدیریت
        </h2>
        <form action="login_ac.php" method="post" class="space-y-7">
            <div>
                <label for="username" class="block text-right text-base font-semibold text-pink-800 mb-2">نام کاربری</label>
                <input type="text" id="username" name="username" required
                    class="block w-full rounded-2xl border-2 border-pink-300 bg-pink-50 py-3 px-4
                           text-pink-900 placeholder-pink-400 shadow-md
                           focus:outline-none focus:border-pink-500 focus:ring-2 focus:ring-pink-400 transition duration-300" 
                    placeholder="نام کاربری خود را وارد کنید">
            </div>

            <div>
                <label for="password" class="block text-right text-base font-semibold text-pink-800 mb-2">رمز عبور</label>
                <input type="password" id="password" name="password" required
                    class="block w-full rounded-2xl border-2 border-pink-300 bg-pink-50 py-3 px-4
                           text-pink-900 placeholder-pink-400 shadow-md
                           focus:outline-none focus:border-pink-500 focus:ring-2 focus:ring-pink-400 transition duration-300"
                    placeholder="رمز عبور خود را وارد کنید">
            </div>

            <div>
                <input type="submit" value="ورود"
                       class="w-full bg-pink-600 hover:bg-pink-700 active:bg-pink-800
                              text-white font-extrabold py-3 rounded-2xl shadow-lg
                              transition-colors duration-300 cursor-pointer select-none
                              hover:shadow-xl focus:outline-none focus:ring-4 focus:ring-pink-500/60">
            </div>
        </form>
    </div>
</div>

<?php include("footer.php"); ?>
