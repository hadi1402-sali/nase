<?php
session_start();
include("header.php");
include("connec.php");
mysqli_set_charset($connect, "utf8mb4");

// گرفتن داده‌ها از فرم
$username = isset($_POST["username"]) ? trim($_POST["username"]) : '';
$password = isset($_POST["password"]) ? trim($_POST["password"]) : '';

// بررسی ورودی‌ها
if (empty($username) || empty($password)) {
    echo "<div class='max-w-md mx-auto mt-20 p-6 bg-red-100 border border-red-400 text-red-700 rounded-xl text-center font-bold'>
            لطفاً نام کاربری و رمز عبور را وارد کنید.
          </div>";
    include("footer.php");
    exit;
}

// بررسی کاربر با prepared statement
$query = "SELECT * FROM `user` WHERE `username` = ? AND `password` = ?";
$stmt = mysqli_prepare($connect, $query);

if (!$stmt) {
    die("<div class='max-w-md mx-auto mt-20 p-6 bg-red-100 border border-red-400 text-red-700 rounded-xl text-center font-bold'>
          خطا در آماده‌سازی دستور SQL: " . htmlspecialchars(mysqli_error($connect)) . "
         </div>");
}

mysqli_stmt_bind_param($stmt, "ss", $username, $password);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($result);

// بستن stmt و اتصال اولیه
mysqli_stmt_close($stmt);

if (!$user) {
    // کاربر یافت نشد
    echo "<div class='max-w-md mx-auto mt-20 p-6 bg-red-100 border border-red-400 text-red-700 rounded-xl text-center font-bold'>
            نام کاربری یا رمز عبور اشتباه است.
          </div>";
    include("footer.php");
    exit;
}

// فقط ادمین اجازه ورود دارد
if ($user['type'] != 0) {
    echo "<div class='max-w-md mx-auto mt-20 p-6 bg-red-100 border border-red-400 text-red-700 rounded-xl text-center font-bold'>
            شما دسترسی به این بخش ندارید.
          </div>";
    include("footer.php");
    exit;
}

// ورود موفق - ذخیره اطلاعات کاربر در سشن و هدایت به پنل ادمین
$_SESSION['user_id'] = $user['id'];
$_SESSION['username'] = $user['username'];
$_SESSION['user_type'] = $user['type'];

header("Location: login_action.php");
exit;

include("footer.php");
?>
