<?php include("header.php"); ?>
<?php
session_start();
include("connec.php");
mysqli_set_charset($connect, "utf8mb4");

// عملیات سبد خرید
if (isset($_GET['remove'])) {
    $id = intval($_GET['remove']);
    unset($_SESSION['cart'][$id]);
    header("Location: cart.php");
    exit;
}
if (isset($_GET['increase'])) {
    $id = intval($_GET['increase']);
    $_SESSION['cart'][$id]++;
    header("Location: cart.php");
    exit;
}
if (isset($_GET['decrease'])) {
    $id = intval($_GET['decrease']);
    if ($_SESSION['cart'][$id] > 1) {
        $_SESSION['cart'][$id]--;
    } else {
        unset($_SESSION['cart'][$id]);
    }
    header("Location: cart.php");
    exit;
}
?>

<main class="container mx-auto px-6 py-12">
    <h1 class="text-4xl font-extrabold mb-10 text-center text-pink-700">سبد خرید شما</h1>

    <?php
    if (!isset($_SESSION['cart']) || count($_SESSION['cart']) == 0) {
        echo "<p class='text-center text-gray-600 text-lg mb-8'>سبد خرید شما خالی است.</p>";
        echo '<div class="text-center">
                <a href="products.php" class="inline-block bg-pink-600 hover:bg-pink-700 text-white font-semibold py-2 px-6 rounded-lg transition duration-300">بازگشت به فروشگاه</a>
              </div>';
    } else {
        $total = 0;
        echo "<div class='overflow-x-auto rounded-2xl shadow-lg border border-pink-200'>";
        echo "<table class='min-w-full bg-white rounded-2xl text-right'>";
        echo "<thead class='bg-pink-50 text-pink-700 font-semibold text-lg'>
                <tr>
                    <th class='py-4 px-6'>تصویر</th>
                    <th class='py-4 px-6'>نام محصول</th>
                    <th class='py-4 px-6'>قیمت واحد</th>
                    <th class='py-4 px-6'>تعداد</th>
                    <th class='py-4 px-6'>جمع</th>
                    <th class='py-4 px-6'>حذف</th>
                </tr>
              </thead><tbody>";

        foreach ($_SESSION['cart'] as $id => $qty) {
            $id = intval($id);
            $res = mysqli_query($connect, "SELECT * FROM images WHERE id = $id");
            $product = mysqli_fetch_assoc($res);
            if (!$product) continue;

            $sum = $product['price'] * $qty;
            $total += $sum;

            echo "<tr class='border-t border-pink-100 hover:bg-pink-50 transition'>
                    <td class='py-4 px-6'>
                        <img src='" . htmlspecialchars($product['image_url']) . "' alt='" . htmlspecialchars($product['name']) . "' class='w-20 h-20 object-cover rounded-xl shadow-md'>
                    </td>
                    <td class='py-4 px-6 text-pink-800 font-semibold'>" . htmlspecialchars($product['name']) . "</td>
                    <td class='py-4 px-6 text-pink-700 font-semibold'>" . number_format($product['price']) . " تومان</td>
                    <td class='py-4 px-6'>
                        <div class='flex items-center justify-center space-x-3 space-x-reverse'>
                            <a href='cart.php?decrease=$id' class='bg-pink-600 text-white px-3 py-1 rounded-full hover:bg-pink-700 transition'>−</a>
                            <span class='font-medium text-pink-700'>" . $qty . "</span>
                            <a href='cart.php?increase=$id' class='bg-pink-600 text-white px-3 py-1 rounded-full hover:bg-pink-700 transition'>+</a>
                        </div>
                    </td>
                    <td class='py-4 px-6 text-pink-800 font-bold'>" . number_format($sum) . " تومان</td>
                    <td class='py-4 px-6'>
                        <a href='cart.php?remove=$id' onclick=\"return confirm('آیا می‌خواهید این محصول حذف شود؟')\" 
                           class='bg-red-500 text-white px-4 py-1 rounded-full hover:bg-red-600 transition'>حذف</a>
                    </td>
                </tr>";
        }

        echo "</tbody></table></div>";

        echo "<p class='text-right mt-8 text-2xl font-extrabold text-pink-700'>جمع کل: " . number_format($total) . " تومان</p>";

        echo '<div class="mt-10 flex justify-center space-x-6 space-x-reverse">
                <a href="products.php" class="inline-block bg-pink-600 hover:bg-pink-700 text-white font-semibold py-3 px-8 rounded-full transition">← بازگشت به فروشگاه</a>
                <a href="#" class="inline-block bg-green-600 hover:bg-green-700 text-white font-semibold py-3 px-8 rounded-full transition">پرداخت</a>
              </div>';
    }
    ?>
</main>
<?php include("footer.php"); ?>
