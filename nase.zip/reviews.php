<?php include("header.php"); ?>

<!-- Customer Reviews Section -->
<section id="reviews" class="py-16 bg-pink-50">
    <div class="container mx-auto px-4">
        <h2 class="text-3xl font-bold text-center text-pink-600 mb-10">نظرات مشتریان</h2>

        <div class="grid md:grid-cols-3 gap-8">
            <!-- Review 1 -->
            <div class="bg-white p-6 rounded-xl shadow-lg review-card">
                <div class="flex items-center mb-4">
                    <img src="https://i.pravatar.cc/100?img=12" alt="Customer" class="w-12 h-12 rounded-full ml-4">
                    <div>
                        <h4 class="font-bold text-gray-800">مریم احمدی</h4>
                        <p class="text-sm text-gray-500">مشهد</p>
                    </div>
                </div>
                <p class="text-gray-700 leading-relaxed">
                    من برای سیسمونی دخترم از این فروشگاه خرید کردم، واقعاً کیفیت عالی و بسته‌بندی زیبا بود. ممنون از تیم دنیای کوچولوها 💖
                </p>
            </div>

            <!-- Review 2 -->
            <div class="bg-white p-6 rounded-xl shadow-lg review-card">
                <div class="flex items-center mb-4">
                    <img src="https://i.pravatar.cc/100?img=22" alt="Customer" class="w-12 h-12 rounded-full ml-4">
                    <div>
                        <h4 class="font-bold text-gray-800">الهه کریمی</h4>
                        <p class="text-sm text-gray-500">تهران</p>
                    </div>
                </div>
                <p class="text-gray-700 leading-relaxed">
                    تنوع محصولاتشون خیلی خوبه، قیمت‌ها هم نسبت به بازار مناسب‌تر بود. حتماً دوباره خرید می‌کنم 🌟
                </p>
            </div>

            <!-- Review 3 -->
            <div class="bg-white p-6 rounded-xl shadow-lg review-card">
                <div class="flex items-center mb-4">
                    <img src="https://i.pravatar.cc/100?img=36" alt="Customer" class="w-12 h-12 rounded-full ml-4">
                    <div>
                        <h4 class="font-bold text-gray-800">سارا عباسی</h4>
                        <p class="text-sm text-gray-500">شیراز</p>
                    </div>
                </div>
                <p class="text-gray-700 leading-relaxed">
                    خیلی راضی‌ام از برخورد پشتیبانی و نحوه ارسال سفارش. به موقع و با کیفیت به دستم رسید. مرسی از شما 💐
                </p>
            </div>
        </div>

        <div class="mt-12 text-center">
            <a href="contact.php" class="inline-block bg-pink-500 hover:bg-pink-600 text-white px-6 py-3 rounded-lg font-medium transition">
                شما هم نظر بدهید
            </a>
        </div>
    </div>
</section>

<?php include("footer.php"); ?>
