<?php
include("header.php");
$conn = new mysqli("localhost", "root", "", "babeshop");
$conn->set_charset("utf8mb4");

if (!isset($_GET['id'])) {
    echo "<div class='text-center text-red-600 mt-10'>محصول مشخص نیست.</div>";
    include("footer.php");
    exit;
}

$id = intval($_GET['id']);
$res = $conn->query("SELECT * FROM images WHERE id = $id");
$product = $res->fetch_assoc();

if (!$product) {
    echo "<div class='text-center text-red-600 mt-10'>محصول یافت نشد.</div>";
    include("footer.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $desc = $_POST['description'];
    $price = $_POST['price'];

    if (!empty($_FILES['image']['name'])) {
        $image_path = 'images/' . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], $image_path);

        $stmt = $conn->prepare("UPDATE images SET name=?, description=?, price=?, image_url=? WHERE id=?");
        $stmt->bind_param("ssdsi", $name, $desc, $price, $image_path, $id);
    } else {
        $stmt = $conn->prepare("UPDATE images SET name=?, description=?, price=? WHERE id=?");
        $stmt->bind_param("ssdi", $name, $desc, $price, $id);
    }

    $stmt->execute();
    header("Location: update_product.php"); // مسیر پنل مدیریتی خود را اینجا تغییر دهید
    exit;
}
?><div class="max-w-3xl mx-auto px-6 py-10 fade-in">
<div class="bg-pink-50 p-8 rounded-3xl shadow-xl border border-pink-200">
    <h2 class="text-3xl font-extrabold text-pink-700 mb-8 text-center tracking-wide drop-shadow-sm">ویرایش محصول</h2>
    <form method="post" enctype="multipart/form-data" class="space-y-6">
        
        <div>
            <label class="block mb-2 text-sm font-semibold text-pink-700 text-right">نام محصول:</label>
            <input type="text" name="name" value="<?= htmlspecialchars($product['name']) ?>"
                class="w-full border border-pink-300 rounded-2xl p-3 focus:ring-4 focus:ring-pink-300 focus:border-pink-500 bg-white shadow-sm transition duration-300" />
        </div>

        <div>
            <label class="block mb-2 text-sm font-semibold text-pink-700 text-right">توضیحات:</label>
            <textarea name="description" rows="5"
                class="w-full border border-pink-300 rounded-2xl p-3 focus:ring-4 focus:ring-pink-300 focus:border-pink-500 bg-white shadow-sm transition duration-300"><?= htmlspecialchars($product['description']) ?></textarea>
        </div>

        <div>
            <label class="block mb-2 text-sm font-semibold text-pink-700 text-right">قیمت (تومان):</label>
            <input type="number" name="price" step="0.01" value="<?= htmlspecialchars($product['price']) ?>"
                class="w-full border border-pink-300 rounded-2xl p-3 focus:ring-4 focus:ring-pink-300 focus:border-pink-500 bg-white shadow-sm transition duration-300" />
        </div>

        <div>
            <label class="block mb-2 text-sm font-semibold text-pink-700 text-right">عکس جدید (اختیاری):</label>
            <input type="file" name="image"
                class="w-full border border-pink-300 rounded-2xl p-3 bg-white shadow-sm transition duration-300 cursor-pointer
                       file:bg-gradient-to-r file:from-pink-400 file:to-pink-600 file:text-white file:font-semibold
                       file:px-4 file:py-2 file:rounded-lg file:shadow-md hover:file:from-pink-500 hover:file:to-pink-700" />
        </div>

        <?php if (!empty($product['image_url'])): ?>
            <div class="text-center mt-6">
                <p class="text-sm text-pink-600 mb-3">تصویر فعلی:</p>
                <img src="<?= htmlspecialchars($product['image_url']) ?>" alt="تصویر فعلی"
                     class="mx-auto rounded-2xl shadow-md max-w-xs border border-pink-200" />
            </div>
        <?php endif; ?>

        <div>
            <button type="submit"
                    class="w-full bg-gradient-to-r from-pink-500 to-pink-700 hover:from-pink-600 hover:to-pink-800
                           text-white font-bold py-4 rounded-2xl shadow-lg transition duration-300 active:scale-95">
                ذخیره تغییرات
            </button>
        </div>
    </form>
</div>
</div>

<?php include("footer.php"); ?>
