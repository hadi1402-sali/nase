<?php include("header.php"); session_start(); ?>

<?php
include("connec.php");
mysqli_set_charset($connect, "utf8mb4");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["product-name"]);
    $price = floatval($_POST["product-price"]);
    $description = trim($_POST["product-description"]);
    $image_url = "";

    if (!empty($_FILES['product-image']['name'])) {
        $target_dir = "images/";
        $filename = time() . "_" . basename($_FILES["product-image"]["name"]);
        $image_url = $target_dir . $filename;

        if (!move_uploaded_file($_FILES["product-image"]["tmp_name"], $image_url)) {
            echo "<div class='text-red-600 font-bold my-4'>❌ خطا در آپلود تصویر.</div>";
        }
    }

    $stmt = mysqli_prepare($connect, "INSERT INTO `images` (`name`, `price`, `description`, `image_url`) VALUES (?, ?, ?, ?)");
    mysqli_stmt_bind_param($stmt, "sdss", $name, $price, $description, $image_url);

    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['success'] = "✅ محصول با موفقیت ثبت شد.";
        header("Location: login_action.php");
        exit;
    } else {
        echo "<div class='text-red-600 font-bold my-4'>❌ خطا در درج محصول: " . mysqli_error($connect) . "</div>";
    }
}
?>

<div class="max-w-3xl mx-auto mt-12 p-10 bg-gradient-to-br from-pink-50 to-pink-100 rounded-3xl shadow-xl border border-pink-300">
    <h2 class="text-4xl font-extrabold text-pink-700 mb-10 text-center border-b border-pink-300 pb-4 tracking-wide drop-shadow-sm">
        افزودن محصول جدید
    </h2>
    
    <form method="post" enctype="multipart/form-data" class="space-y-8">
        <div>
            <label class="block mb-3 text-right font-semibold text-pink-700 text-lg">نام محصول</label>
            <input name="product-name" required
                class="w-full border border-pink-300 rounded-3xl px-6 py-4 text-pink-900 placeholder-pink-400 shadow-inner
                       focus:outline-none focus:ring-4 focus:ring-pink-300 focus:border-pink-500 transition duration-300"
                type="text" placeholder="نام محصول را وارد کنید" />
        </div>

        <div>
            <label class="block mb-3 text-right font-semibold text-pink-700 text-lg">قیمت (تومان)</label>
            <input name="product-price" required step="0.01"
                class="w-full border border-pink-300 rounded-3xl px-6 py-4 text-pink-900 placeholder-pink-400 shadow-inner
                       focus:outline-none focus:ring-4 focus:ring-pink-300 focus:border-pink-500 transition duration-300"
                type="number" placeholder="قیمت محصول را وارد کنید" />
        </div>

        <div>
            <label class="block mb-3 text-right font-semibold text-pink-700 text-lg">توضیحات</label>
            <textarea name="product-description" rows="6"
                class="w-full border border-pink-300 rounded-3xl px-6 py-4 text-pink-900 placeholder-pink-400 shadow-inner
                       focus:outline-none focus:ring-4 focus:ring-pink-300 focus:border-pink-500 transition duration-300 resize-none"
                placeholder="توضیحات محصول را وارد کنید"></textarea>
        </div>

        <div>
            <label class="block mb-3 text-right font-semibold text-pink-700 text-lg">تصویر محصول</label>
            <input name="product-image" type="file" accept="image/*"
                class="w-full border border-pink-300 rounded-3xl px-5 py-3 cursor-pointer
                       file:bg-gradient-to-r file:from-pink-400 file:to-pink-600 file:text-white file:font-semibold
                       file:px-5 file:py-3 file:rounded-2xl file:shadow-md hover:file:from-pink-500 hover:file:to-pink-700 transition duration-300" />
        </div>

        <div>
            <button type="submit"
                class="w-full bg-gradient-to-r from-pink-500 to-pink-700 hover:from-pink-600 hover:to-pink-800
                       text-white font-extrabold py-5 rounded-3xl shadow-lg transition duration-300 active:scale-95">
                ثبت محصول
            </button>
        </div>
    </form>
</div>

<?php include("footer.php"); ?>
