  <!-- Footer -->
  <footer class="bg-gray-800 text-white pt-12 pb-6">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
                <div>
                    <h3 class="text-xl font-bold mb-4 flex items-center">
                        <div class="w-8 h-8 bg-pink-500 rounded-full flex items-center justify-center mr-2">
                            <i class="fas fa-baby"></i>
                        </div>
                        دنیای کوچولوها
                    </h3>
                    <p class="text-gray-400 mb-4">فروشگاه تخصصی سیسمونی و لوازم نوزاد با ارائه بهترین و باکیفیت ترین محصولات برای فرزندان دلبند شما</p>
                    <div class="flex space-x-4 space-x-reverse">
                        <a href="#" class="w-8 h-8 bg-gray-700 hover:bg-pink-500 rounded-full flex items-center justify-center transition">
                            <i class="fab fa-instagram"></i>
                        </a>
                        <a href="#" class="w-8 h-8 bg-gray-700 hover:bg-blue-500 rounded-full flex items-center justify-center transition">
                            <i class="fab fa-telegram"></i>
                        </a>
                        <a href="#" class="w-8 h-8 bg-gray-700 hover:bg-blue-400 rounded-full flex items-center justify-center transition">
                            <i class="fab fa-twitter"></i>
                        </a>
                        <a href="#" class="w-8 h-8 bg-gray-700 hover:bg-red-600 rounded-full flex items-center justify-center transition">
                            <i class="fab fa-youtube"></i>
                        </a>
                    </div>
                </div>
                
                <div>
                    <h3 class="text-lg font-bold mb-4">لینک های مفید</h3>
                    <ul class="space-y-2">
                        <li><a href="index.php" class="text-gray-400 hover:text-white transition">صفحه اصلی</a></li>
                        <li><a href="products.php" class="text-gray-400 hover:text-white transition">محصولات</a></li>
                        <li><a href="about.php" class="text-gray-400 hover:text-white transition">درباره ما</a></li>
                        <li><a href="reviews.php" class="text-gray-400 hover:text-white transition">نظرات مشتریان</a></li>
                        <li><a href="contact.php" class="text-gray-400 hover:text-white transition">تماس با ما</a></li>
                    </ul>
                </div>
                
                
                
                <div>
                    <h3 class="text-lg font-bold mb-4">عضویت در خبرنامه</h3>
                    <p class="text-gray-400 mb-4">با عضویت در خبرنامه از جدیدترین محصولات و تخفیف ها با خبر شوید</p>
                    <form class="flex">
                        <input type="email" placeholder="ایمیل شما" class="bg-gray-700 text-white px-4 py-2 rounded-r-lg focus:outline-none focus:ring-2 focus:ring-pink-500 w-full">
                        <button type="submit" class="bg-pink-500 hover:bg-pink-600 text-white px-4 py-2 rounded-l-lg transition">
                            <i class="fas fa-paper-plane"></i>
                        </button>
                    </form>
                </div>
            </div>
            
            <div class="border-t border-gray-700 pt-6 flex flex-col md:flex-row justify-between items-center">
                <p class="text-gray-400 text-sm mb-4 md:mb-0">© 1402 کلیه حقوق برای فروشگاه دنیای کوچولوها محفوظ است.</p>
                <div class="flex space-x-6 space-x-reverse">
                    <img src="https://logo.samandehi.ir/logo.aspx?id=123456" alt="Samandehi" class="h-10">
                    <img src="https://trustseal.enamad.ir/logo.aspx?id=123456" alt="Enamad" class="h-10">
                </div>
            </div>
        </div>
    </footer>