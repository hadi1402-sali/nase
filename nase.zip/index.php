<?php include("header.php");?>
<section id="home" class="hero-pattern py-16">
  <div class="container mx-auto px-4 flex flex-col md:flex-row items-center">
    <div class="md:w-1/2 mb-10 md:mb-0">
      <h2 class="text-4xl md:text-5xl font-bold text-gray-800 mb-4">سیسمونی نوزاد با کیفیت و قیمت مناسب</h2>
      <p class="text-lg text-gray-600 mb-6">همه چیز برای آسایش و زیبایی کوچولوی دلبند شما</p>
      <div class="flex space-x-4 space-x-reverse">
        <a href="products.php" class="bg-pink-500 hover:bg-pink-600 text-white px-6 py-3 rounded-lg font-medium transition">مشاهده محصولات</a>
        <a href="about.php" class="border border-pink-500 text-pink-500 hover:bg-pink-50 px-6 py-3 rounded-lg font-medium transition">درباره ما</a>
      </div>
    </div>

    <div class="md:w-1/2 relative">
      <div class="relative">
        <!-- تصویر اصلی -->
        <img src="https://mag.parsnews.com/wp-content/uploads/2023/02/images_1675593083_63df857bae04a.jpg"alt="Flowers" class="w-full h-auto rounded-lg shadow-md">
        
        <!-- تصویر شناور ۱ -->
        <div class="absolute -bottom-6 -left-6 bg-white p-3 rounded-lg shadow-lg floating">
          <img src="https://yeto.ir/wp-content/uploads/2024/03/lebas1-32.jpg"
               alt="پوشک نوزادی"
               class="w-20 h-20 object-cover rounded-lg">
        </div>

        <!-- تصویر شناور ۲ -->
        <div class="absolute -top-6 -right-6 bg-white p-3 rounded-lg shadow-lg floating delay-1">
          <img src="https://snapp.market/blog/wp-content/uploads/2022/04/baby-diapers-types-2.jpg"
               alt="لباس نوزاد"
               class="w-20 h-20 object-cover rounded-lg">
        </div>

        <!-- تصویر شناور ۳ -->
        <div class="absolute top-1/2 -left-10 bg-white p-3 rounded-lg shadow-lg floating delay-2">
          <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSaYZ6nzPyBGcAk-I8ymgeupqn8ZRHGUQQO8A&s"
               alt="اسباب‌بازی نوزاد"
               class="w-20 h-20 object-cover rounded-lg">
        </div>
      </div>
    </div>
  </div>
</section>


<?php include("footer.php");?>